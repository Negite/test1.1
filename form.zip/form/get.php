﻿<? 
//    header('Content-Type: text/html; charset=utf-8');

$name = $_GET['name'];
echo 'Имя:'.$name.'<br/>';

$message = $_GET['message'];
echo 'Сообщение:'.$message.'<br/>'; 


?>